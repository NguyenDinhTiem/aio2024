import streamlit as st
from supabase import Client, create_client

@st.cache_resource
def init_connection() -> Client:
    try:
        return create_client(
            st.secrets["connections"]["supabase"]["SUPABASE_URL"],
            st.secrets["connections"]["supabase"]["SUPABASE_KEY"],
        )
    except KeyError:
        return create_client(st.secrets["SUPABASE_URL"], st.secrets["SUPABASE_KEY"])


def login_success(message: str, username: str) -> None:

    st.success(message)
    st.session_state["authenticated"] = True
    st.session_state["username"] = username
    st.rerun()

def login_tab_st(
    allow_guest,
    create_title,
    login_title,
    guest_title):
        
    if allow_guest:
        create_tab, login_tab, guest_tab = st.tabs(
            [
                create_title,
                login_title,
                guest_title,
            ]
        )
        return create_tab, login_tab, guest_tab
    else:
        create_tab, login_tab = st.tabs(
            [
                create_title,
                login_title,
            ]
        )
        return create_tab, login_tab

def create_new_account(
    create_username_label,
    create_username_placeholder,
    create_username_help, create_password_label,
    create_password_placeholder, create_password_help,
    create_submit_label,
    create_success_message,
    user_tablename,
    username_col,
    password_col,
    client):
    
    with st.form(key="create"):
        username = st.text_input(
            label=create_username_label,
            placeholder=create_username_placeholder,
            help=create_username_help,
            disabled=st.session_state["authenticated"],
        )

        password = st.text_input(
            label=create_password_label,
            placeholder=create_password_placeholder,
            help=create_password_help,
            type="password",
            disabled=st.session_state["authenticated"],
        )

        if st.form_submit_button(
            label=create_submit_label,
            type="primary",
            disabled=st.session_state["authenticated"],
        ):
            try:
                data, _ = (
                    client.table(user_tablename)
                    .insert({username_col: username, password_col: password})
                    .execute()
                )
                
            except Exception as e:
                st.error(str(e))
            else:
                login_success(create_success_message, username)

def login_existing_account(
    login_username_label,login_username_placeholder,
    login_username_help, login_password_label,
    login_password_placeholder, login_password_help,
    login_submit_label, login_success_message,
    login_error_message, user_tablename,
    username_col, password_col, client):
    
    with st.form(key="login"):
        username = st.text_input(
            label=login_username_label,
            placeholder=login_username_placeholder,
            help=login_username_help,
            disabled=st.session_state["authenticated"],
        )

        password = st.text_input(
            label=login_password_label,
            placeholder=login_password_placeholder,
            help=login_password_help,
            type="password",
            disabled=st.session_state["authenticated"],
        )

        if st.form_submit_button(
            label=login_submit_label,
            disabled=st.session_state["authenticated"],
            type="primary",
        ):
            data, _ = (
                client.table(user_tablename)
                .select(f"{username_col}, {password_col}")
                .eq(username_col, username)
                .eq(password_col, password)
                .execute()
            )

            if len(data[-1]) > 0:
                login_success(login_success_message, username)
            else:
                st.error(login_error_message)

def guest_login(guest_submit_label):
    if st.button(
            label=guest_submit_label,
            type="primary",
            disabled=st.session_state["authenticated"],
        ):
            st.session_state["authenticated"] = True
            st.session_state["username"] = "guess_aivn"
            st.rerun()
# Create the python function that will be called
def login_form(
    title: str = "AIO CODE EDITOR",
    user_tablename: str = "users",
    username_col: str = "username",
    password_col: str = "password",
    create_title: str = "Tạo tài khoản mới :baby: ",
    login_title: str = "Đăng nhập :prince: ",
    allow_guest: bool = True,
    guest_title: str = "Khách :ninja: ",
    create_username_label: str = "Nhập tên đăng nhập",
    create_username_placeholder: str = None,
    create_username_help: str = None,
    create_password_label: str = "Nhập mật khẩu",
    create_password_placeholder: str = None,
    create_password_help: str = "⚠️ Nên đặt mật khẩu mạnh gồm cả chữ và số",
    create_submit_label: str = "Tạo tài khoản",
    create_success_message: str = "Đã tạo tài khoản thành công :tada:",
    login_username_label: str = "Nhập tên đăng nhập",
    login_username_placeholder: str = None,
    login_username_help: str = None,
    login_password_label: str = "Nhập mật khẩu",
    login_password_placeholder: str = None,
    login_password_help: str = None,
    login_submit_label: str = "Đăng nhập",
    login_success_message: str = "Đăng nhập thành công :tada:",
    login_error_message: str = "Sai tên đăng nhập hoặc mật khẩu :x: ",
    guest_submit_label: str = "Đăng nhâp với tư cách khách",
) -> Client:
    """Creates a user login form in Streamlit apps.

    Connects to a Supabase DB using `SUPABASE_URL` and `SUPABASE_KEY` Streamlit secrets.
    Sets `session_state["authenticated"]` to True if the login is successful.
    Sets `session_state["username"]` to provided username or new or existing user, and to `None` for guest login.

    Returns:
    Supabase client instance
    """

    # Initialize supabase connection
    client = init_connection()

    # User Authentication
    if "authenticated" not in st.session_state:
        st.session_state["authenticated"] = False

    if "username" not in st.session_state:
        st.session_state["username"] = None

    with st.expander(title, expanded=not st.session_state["authenticated"]):
        # Create tabs
        tabs = login_tab_st(allow_guest, create_title, login_title, guest_title)
        if len(tabs) == 3:
            create_tab, login_tab, guest_tab = tabs
        else:
            create_tab, login_tab = tabs

        # Create new account
        with create_tab:
            create_new_account(
                create_username_label,
                create_username_placeholder,
                create_username_help, create_password_label,
                create_password_placeholder, create_password_help,
                create_submit_label,
                create_success_message,
                user_tablename,
                username_col,
                password_col,
                client)

        # Login to existing account
        with login_tab:
            login_existing_account(
                login_username_label,login_username_placeholder,
                login_username_help, login_password_label,
                login_password_placeholder, login_password_help,
                login_submit_label, login_success_message,
                login_error_message, user_tablename,
                username_col, password_col, client)
        # Guest login
        if allow_guest:
            with guest_tab:
                guest_login(guest_submit_label)
        
        return client


def main() -> None:
    login_form(
        create_username_placeholder="Tạo tên đăng nhập của bạn, ví dụ 'nguyenvana'",
        create_password_placeholder="Đặt mật khẩu của bạn",
        guest_submit_label="Khách đăng nhập",
    )
    st.write(st.session_state)


if __name__ == "__main__":
    main()