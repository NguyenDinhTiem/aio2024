import streamlit as st
from code_editor import code_editor
from aio_code_editor.css import info_bar_input, info_bar_output, output_btns, input_btns
import subprocess
from aio_code_editor.until import check_code, write_code
import os
import sys
import importlib
import csv
import pandas as pd
import re
import random
import webbrowser
import urllib.parse


environ = os.environ.copy()
environ['PYTHONIOENCODING'] = 'utf-8'

def side_bar():
    with st.sidebar:
        st.markdown("## :heartbeat: :heartbeat: Hướng dẫn  :heartbeat: :heartbeat:")
        st.markdown("1. Đặt tên file (không bắt buộc)")
        st.markdown("2. Viết mã Python vào ô bên dưới")
        st.markdown("3. Nhấn nút **Run** để thực thi mã")
        st.markdown("4. Kết quả sẽ hiển thị ở ô bên dưới")
        st.markdown("5. Bạn có thể tải file Python bằng cách nhấn vào nút **Save file**")
        
        file_name = st.text_input("Tên file:", "st_test.py")
        st.write("Chill chút nhỉ? ^^")
        st.audio("https://cdn.pixabay.com/audio/2023/01/10/audio_5f83ba4572.mp3", format="audio/mp3")
        st.audio("https://cdn.pixabay.com/audio/2023/04/30/audio_6b3a512606.mp3", format="audio/mp3")
        st.audio("https://ia800209.us.archive.org/12/items/ECHOSAXEND/ECHOSAXEND.mp3", format="audio/mp3")
        
        return file_name
    
def heading():
    col_1, col_2, col_3 = st.columns([0.2, 0.5, 0.4])
    with col_2:
        st.title("AIO Code Editor")
    with col_3:
        st.image("https://ia800202.us.archive.org/30/items/shark_202403/shark.png", width=150)

def codes_box(sample_code, min_raw=5, max_raw=20, type_out="python", file_name="st_test.py",show_now=True, key=None):
    """
    Args:
        sample_code (_type_): sample code to show in code editor
        min_raw (int, optional): min of raw value in code box. Defaults to 5.
        max_raw (int, optional): max of raw value in code box. Defaults to 20.
        type_out (str, optional): Type of output, have 2 type of output are python and plot(plot to show streamlit code). Defaults to "python".
        file_name (str, optional): File name. Defaults to "st_test.py".
        key (_type_, optional): key of box code. Defaults to None.

    Returns:
        code_ex, res_type, response_dict, line_nums
    """
    response_dict = code_editor(sample_code, buttons=input_btns, height=[min_raw, max_raw], info= info_bar_input, key=key)
    code_ex = response_dict["text"]
    line_nums = len(sample_code.split('\n'))    
    res_type = response_dict["type"]
    if type_out=="plot" or (type_out=="python" and show_now is True) :
        write_code(sample_code, file_name)
        response_dict['cursor'] = {'row':line_nums}
        
    return code_ex, res_type, response_dict, line_nums

def output_box(response_dict, results, min_raw=5, max_raw=20, err=0, key=None):
    key = key + str(random.random())
    num_rows = response_dict['cursor']['row']
    if num_rows<=min_raw:
        code_editor(results, buttons=output_btns, height= [min_raw, min_raw], info=info_bar_output, key=key)
    elif num_rows>=max_raw:
        code_editor(results, buttons=output_btns, height= [max_raw, max_raw] , info=info_bar_output, key=key)
             
    elif num_rows>min_raw and num_rows<max_raw:
        code_editor(results, buttons=output_btns, height= [num_rows, num_rows], info=info_bar_output, key=key)

def dowload_file(file_name):
    st.download_button(
                    label="Save file",
                    data=open(file_name, 'rb').read(),
                    file_name= file_name,
                    mime="text/plain")
    
def run_module_by_import(file_name):
    module_name  = file_name.split(".")[0]
    module_name = module_name.replace("/", ".")
    if module_name in sys.modules:
        importlib.reload(sys.modules[module_name])
    else:
        importlib.import_module(module_name)

def run_plot(file_name, code_ex, res_type, download=False):
    if check_code(code_ex):  
        if res_type == "":
            # Hiển thị button đownload file
            if download:
                dowload_file(file_name)
            # Thực thi file Python và lấy đầu ra và lỗi (nếu có)
            run_module_by_import(file_name)
        elif res_type == "submit":
            # Lưu mã vào file Python
            write_code(code_ex, file_name)
            # Hiển thị button đownload file
            if download:
                dowload_file(file_name)
            # Thực thi file Python và lấy đầu ra và lỗi (nếu có)
            run_module_by_import(file_name)
        
                
def run_code(file_name, code_ex, res_type, response_dict, download=False, test_cases="", key=None, show_now=False):
    if check_code(code_ex):     
        
        if res_type == "submit":
            if test_cases != "":
                code_ex = code_ex + "\n" + test_cases
            # Lưu mã vào file Python
            write_code(code_ex, file_name)
            # Hiển thị button đownload file
            if download:
                dowload_file(file_name)
            # Thực thi file Python và lấy đầu ra và lỗi (nếu có)
            result = subprocess.run(['python', file_name], encoding="utf-8", env=environ, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            # Hiển thị kết quả trong output_box
            if result.stderr == "":
                output_box(response_dict, result.stdout, key=key)
            elif result.stdout == "":
                output_box(response_dict, result.stderr, err=1, key=key)
            else:
                output_box(response_dict, f"{result.stdout}\n{result.stderr}", err=1, key=key)
        elif res_type =='' and show_now == True:
            # Hiển thị button đownload file
            if download:
                dowload_file(file_name)
            # Thực thi file Python và lấy đầu ra và lỗi (nếu có)
            result = subprocess.run(['python', file_name], encoding="utf-8", env=environ, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            # Hiển thị kết quả trong output_box
            if result.stderr == "":
                output_box(response_dict, result.stdout, key=key)
            elif result.stdout == "":
                output_box(response_dict, result.stderr, err=1, key=key)
            else:
                output_box(response_dict, f"{result.stdout}\n{result.stderr}", err=1, key=key)
            
    else:
        st.error("Mã của bạn có thể nguy hiểm, vui lòng kiểm tra lại!")
    return result

def debug_process(res_type, debug=False, show_debug=False, file_name="st_test.py", debug_txt ="st_test_output.txt" ,debug_csv="st_test_output.csv"):
    if res_type == "submit" and debug:
        bt_db = st.button("Debug")
        if bt_db:
            st.session_state.bt_db = True
            pdb_custorm(file_name, debug_txt)  # Make sure to provide a file name
            debug_codes(debug_txt, debug_csv)
        
        if 'bt_db' in st.session_state:
            df = pd.read_csv(debug_csv)
            # Initialize the number of rows in session state if not already set
            if 'number_of_rows' not in st.session_state:
                st.session_state["number_of_rows"] = 0

            # Create a button to load more rows from the dataframe
            if st.button("Next"):
                st.session_state.number_of_rows += 1
                st.table(df.head(st.session_state["number_of_rows"]))
                
                if show_debug:
                    line = st.session_state["number_of_rows"]-1
                    if line >=len(df):
                        line = 0
                    current_line = get_current_line(file_name, df, line)
                    show_code_debug(file_name, current_line= current_line)
                
            if st.button("Reset"):
                st.session_state.bt_db = False
                st.session_state.number_of_rows = 0
                st.table(df.head(st.session_state["number_of_rows"]))

def code_box_process(sample, l=1, r=1, min_raw=5, max_raw=20, download=False, key=None, type_out="python", show_now =True, file_name="st_test.py", test_cases=""):
    """_summary_

    Args:
        sample (_type_): _description_
        l (int, optional): _description_. Defaults to 1.
        r (int, optional): _description_. Defaults to 1.
        min_raw (int, optional): _description_. Defaults to 5.
        max_raw (int, optional): _description_. Defaults to 20.
        download (bool, optional): _description_. Defaults to False.
        key (_type_, optional): _description_. Defaults to None.
        type_out (str, optional): _description_. Defaults to "python".
        show_now (bool, optional): _Tự động thực hiện ví dụ và hiển thị_. Defaults to True.
        file_name (str, optional): _description_. Defaults to "st_test.py".
        test_cases (str, optional): _description_. Defaults to "".

    Returns:
        _(result, restype)_: _Dùng trong trường hợp chấm điểm_
    """
    col1, col2 = st.columns([l, r])
    with col1:
        if type_out == "plot":
            code_ex, res_type, response_dict, line_nums = codes_box(sample, min_raw, max_raw, type_out="plot",file_name=file_name, key=key)
        elif type_out == "python" and show_now is True:
            code_ex, res_type, response_dict, line_nums = codes_box(sample, min_raw, max_raw, type_out="python", file_name=file_name, show_now=show_now, key=key)
        else:
            code_ex, res_type, response_dict, line_nums = codes_box(sample, min_raw, max_raw, key=key)

    result=None
    with col2:
        if res_type=="" and type_out=="python" and show_now is False:
            if line_nums<min_raw:
                line_nums = min_raw
            if line_nums>max_raw:
                line_nums = max_raw
                
            code_editor("", buttons=output_btns, height= [line_nums, max_raw] , info=info_bar_output, key=key+'_')
        elif res_type=="" and type_out=="plot":
            run_plot(file_name=file_name, code_ex=code_ex, res_type=res_type, download=download)

        elif res_type=="" and type_out=="python" and show_now is True:
            result = run_code(file_name=file_name, code_ex=code_ex, res_type=res_type, response_dict=response_dict, download=download, test_cases=test_cases, key=key, show_now=show_now)
            code_ex = sample
        else:
            if type_out=="python":
                result = run_code(file_name=file_name, code_ex=code_ex, res_type=res_type, response_dict=response_dict, download=download, test_cases=test_cases, key=key)
            elif type_out=="plot":
                run_plot(file_name=file_name, code_ex=code_ex, res_type=res_type, download=download)
    return result, code_ex, res_type

def code_io(sample=''' ''', l=1, r=1, min_raw=5, max_raw=20, download=False, key=None, type_out="python", show_now=True, file_name="st_test.py", solution="", mark=False, mark_assert=False, test_cases="", debug=False, show_debug=False):
    # Process code box
    result, code_ex, res_type =  code_box_process(sample, l, r, min_raw, max_raw, download, key, type_out, show_now, file_name, test_cases)
    st.markdown("""<style>
    button {
    height: auto;
    padding-top: 12px !important;
    padding-bottom: 12px !important;
    }
    </style>
    """ ,unsafe_allow_html=True)

    if result.stderr != '':
        col1, col2 = st.columns([1, 1])
        with col1:
            st.error("Bạn sửa mãi không hết lỗi, click vào nút bên cạnh để hỏi AI nhé! 👉", icon="🚨")
        with col2:
            if st.button("Hỏi AI🤖", key=key+'bt1'):
                query1 = f"Bạn là chuyên gia Python, chương trình python của tôi: {code_ex} bị lỗi {result_stderr} hãy sửa lỗi này cho tôi!"
                encoded_query = urllib.parse.quote(query1, safe='')
                url = f'https://www.phind.com/search?q={encoded_query}'
                
                js_code = f"window.open('{url}');"
                st.components.v1.html(f"<script>{js_code}</script>")
    else:
        col1, col2 = st.columns([1, 1])
        with col1:
            st.info("Bạn đọc mãi mà không hiểu code, click vào nút bên cạnh để hỏi AI nhé! 👉", icon="ℹ️")
        with col2:
            if st.button("Hỏi AI🤖", key=key+'bt2'):
                query2 = f"Bạn là chuyên gia Python, hãy giải thích thật dễ hiểu chương trình python: {code_ex}"
                encoded_query = urllib.parse.quote(query2, safe='')
                url = f'https://www.phind.com/search?q={encoded_query}'
                js_code = f"window.open('{url}');"
                st.components.v1.html(f"<script>{js_code}</script>")
    # Debug process
    debug_csv = file_name.split(".")[0]+"_output.csv"
    debug_txt = file_name.split(".")[0]+"_output.txt"
    debug_process(res_type, debug=debug, show_debug=show_debug, file_name=file_name, debug_txt=debug_txt, debug_csv=debug_csv)
    
    # mark exercise
    if mark and res_type!="":
        student_ex = result.stdout.strip("\n")
        solution = solution.strip("\n")
        mark_exercise(solution, student_ex)
        
    if mark_assert and res_type!="":
        mark_by_assert(result)

def mark_exercise(solution:str, student_ex:str):
    if solution == student_ex:
        st.success("Bạn làm đúng rồi! :tada:")
    else:
        st.error("Bài làm chưa đúng, hãy thử lại nhé! :cry:")

def mark_by_assert(student_ex:str):
    if student_ex.stdout == "" and student_ex.stderr == "":
        st.success("Bạn làm đúng rồi! :tada:")
    else:
        st.error("Bài làm chưa đúng, hãy thử lại nhé! :cry:")

def debug_codes(debug_txt, debug_csv):
    # Load the debugging output file
    with open(debug_txt, 'r') as file:
        debug_output = file.readlines()
        
    code_ex = []
    var_values = []
    for i in debug_output:
        if i == "The program finished and will be restarted\n":
            break
        else:
            if i.startswith("->"):
                code_ex.append(i.strip("\n"))
            if i.startswith("    for supporting Python development"):
                first_pos = i.find('}')
                second_pos = i.find('}', first_pos + 1) if first_pos != -1 else -1
                var_values.append(i[first_pos+1:second_pos])
    # st.write(code_ex)
    # st.write(var_values)
    # write to csv step, code, variables 
    with open(debug_csv, mode='w') as file:
        writer = csv.writer(file)
        writer.writerow(["Step", "Code", "Variables"])
        for i in range(len(code_ex)-2):
            writer.writerow([i+1, code_ex[i], var_values[i+1]])

def pdb_custorm(file_name ='st_test.py', debug_txt ='st_test_output.txt'):
    
        # Get number of lines in the file
    with open(file_name, 'r') as file:
        lines = file.readlines()
        num_lines = len(lines)
    process = subprocess.Popen(['python', '-m', 'pdb', file_name],
                            stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            text=True)
    commands = [
    'locals()\n',
    'next\n'
    ]*(num_lines+10)

    # Gửi các lệnh vào tiến trình con và nhận kết quả
    for command in commands:
        process.stdin.write(command)

    # Kết thúc việc gửi dữ liệu vào tiến trình con
    # process.stdin.close()

    # Đọc dữ liệu đầu ra từ tiến trình con
    output, errors = process.communicate()
    
    # write output to file
    with open(debug_txt, 'w') as f:
        f.write(output)

def highlight_line(code_lines, current_line, tab_size=4):
    highlighted_code = "<pre>"
    for i, line in enumerate(code_lines, 1):
        # Xử lý khoảng trắng và tab trước
        line = line.replace('\t', ' ' * tab_size).replace(' ', '&nbsp;')

        # Kiểm tra và xử lý ký tự xuống dòng ở cuối mỗi dòng
        if line.endswith('\n'):
            line = line[:-1] + '<br>'  # Thay thế ký tự xuống dòng bằng <br>
        else:
            line += '<br>'  # Đảm bảo mọi dòng đều kết thúc bằng <br>

        # Áp dụng highlight cho dòng hiện tại
        if i == current_line:
            highlighted_code += f'<span class="current-line">{line}</span>'
        else:
            highlighted_code += line
    highlighted_code += "</pre>"
    return highlighted_code

def show_code_debug(file_name = 'st_test.py', current_line=1):
    st.markdown("""
    <style>
    pre {
        border: 1px solid #ccc;
        padding: 5px;
        background-color: #f8f9fa;
        white-space: pre-wrap;
        word-break: keep-all;
    }
    .current-line {
        background-color: #90EE90;  /* Yellow background for the current line */
        display: block;
    }
    </style>
    """, unsafe_allow_html=True)
    with open(file_name, 'r') as file:
        code_lines = file.readlines()
    code_lines = [line for line in code_lines if line!="\n"]
    highlighted_code = highlight_line(code_lines, current_line)
    st.markdown(highlighted_code, unsafe_allow_html=True)

def get_current_line(file_name='st_test.py', debug_frame=None, line=None):
    with open(file_name, 'r') as file:
        code_lines = file.readlines()
    code_debug = debug_frame["Code"][line]
    # remove special characters
    code_debug = re.sub(r"[-> ]+", '', code_debug)
    
    # get index of line in code_lines
    code_lines_clean = [re.sub(r"[-> ]+", '', i.strip("\n")) for i in code_lines]
    if code_debug in code_lines_clean:
        current_line = code_lines_clean.index(code_debug)
    else:
        current_line = 1
    return current_line